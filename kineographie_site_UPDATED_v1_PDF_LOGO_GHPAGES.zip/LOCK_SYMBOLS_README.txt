KINÉO-GRAPHIE — SYMBOLS ARE LOCKED

Important folders/files (do NOT change unless you WANT to change symbols):
1) assets/icons/ptable/          -> 111 PNG icons (1.png to 111.png)
2) signes.json                   -> each item has glyph: "img:assets/icons/ptable/<id>.png"
3) symbols.lock.css              -> ONLY place that controls symbol size/box on the site

If we work on other pages:
- It's safe to edit HTML content, text, sections, colors, etc.
- Avoid touching the 3 items above.
