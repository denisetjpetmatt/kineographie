
/* Kinéo-graphie – app.js (v24) */
(function(){
  'use strict';

  function qs(sel, root){ return (root||document).querySelector(sel); }
  function qsa(sel, root){ return Array.prototype.slice.call((root||document).querySelectorAll(sel)); }
  function escapeHTML(s){
    return (s==null?'':String(s))
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }

  var SUPER = new Set(['Lf','Lr','Mr']); // exposants (biomécanique)

  // Resolve asset paths so the site works both at domain root (e.g., Netlify)
  // and under a GitHub Pages project subpath (e.g., https://user.github.io/repo/).
  function basePath(){
    try {
      var host = (location.hostname || '').toLowerCase();
      var path = (location.pathname || '/');

      // GitHub Pages: user sites are at /, project sites are at /<repo>/...
      if (host.endsWith('github.io')){
        var parts = path.split('/').filter(Boolean);
        // If the first segment looks like a file (contains a dot), treat as user site.
        if (parts.length === 0 || parts[0].indexOf('.') !== -1) return '/';
        return '/' + parts[0] + '/';
      }
    } catch(e){}
    return '/';
  }

  function joinBase(base, rel){
    base = (base || '/');
    rel = (rel || '').replace(/^\.\//,'').replace(/^\//,'');
    if (!base.endsWith('/')) base += '/';
    return base + rel;
  }

  function glyphToHTML(g){
    g = (g||'').toString();

    if (g.indexOf('img:') === 0){
      var src = g.slice(4).trim();
      // Make paths robust for "pretty URLs" and for GitHub Pages subpaths.
      // Always load from the site base ("/" on Netlify/custom domains, "/<repo>/" on GitHub Pages project sites).
      var base = basePath();
      if (src.indexOf('./assets/') === 0){
        src = joinBase(base, 'assets/' + src.slice('./assets/'.length));
      } else if (src.indexOf('assets/') === 0){
        src = joinBase(base, src);
      } else if (src.indexOf('/assets/') === 0){
        // If an absolute path sneaks in, re-base it.
        src = joinBase(base, src.slice(1));
      }
      return '<img class="glyph-img" src="'+escapeHTML(src)+'" alt="Signe" />';
    }

    var m = g.match(/^([A-ZÀ-ÖØ-Þ])([a-zà-öø-ÿ]{1,3})$/);
    if (m){
      var base = m[1];
      var sub = m[2];
      var cls = SUPER.has(g) ? 'g-code g-super' : 'g-code';
      return '<span class="'+cls+'"><span class="g-base">'+escapeHTML(base)+'</span><span class="g-sub">'+escapeHTML(sub)+'</span></span>';
    }

    return '<span class="g-single">'+escapeHTML(g || '□')+'</span>';
  }

  function initQuickModal(allSigns){
    var openBtn = qs('#openQuickSigns');
    var modal = qs('#quickSignModal');
    if (!openBtn || !modal || !allSigns) return;

    var backdrop = qs('#quickBackdrop');
    var closeBtn = qs('#quickClose');
    var search = qs('#quickSearch');
    var grid = qs('#quickGrid');
    var count = qs('#quickCount');

    function open(){
      modal.classList.add('open');
      modal.setAttribute('aria-hidden','false');
      if (search){ search.value=''; search.focus(); }
      render();
    }
    function close(){
      modal.classList.remove('open');
      modal.setAttribute('aria-hidden','true');
    }
    function render(){
      var q = (search && search.value || '').trim().toLowerCase();
      var filtered = allSigns.filter(function(s){
        if (!q) return true;
        return (s.glyph||'').toLowerCase().includes(q) ||
               (s.name||'').toLowerCase().includes(q) ||
               String(s.id||'').includes(q);
      });
      if (count) count.textContent = filtered.length + ' / ' + allSigns.length;
      if (!grid) return;

      // Render as a "palette" so it matches the existing CSS (clean, centered, no text overlap).
      grid.innerHTML = filtered.map(function(s){
        return '<a href="signes.html#signe-'+escapeHTML(s.id)+'" title="'+escapeHTML(s.name)+'">' +
                 '<div class="p-id">#'+escapeHTML(s.id)+'</div>' +
                 '<div class="p-glyph">'+glyphToHTML(s.glyph)+'</div>' +
               '</a>';
      }).join('');
    }

    openBtn.addEventListener('click', open);
    if (backdrop) backdrop.addEventListener('click', close);
    if (closeBtn) closeBtn.addEventListener('click', close);
    if (search) search.addEventListener('input', render);

    document.addEventListener('keydown', function(e){
      if (e.key === 'Escape' && modal.classList.contains('open')) close();
    });
  }

  function initSignsPage(allSigns){
    var grid = qs('#signGrid');
    if (!grid || !allSigns) return;

    var search = qs('#signSearch');
    var filterWrap = qs('#signFilters');
    var count = qs('#signCount');

    // Tabs (single category) instead of multi-select checkboxes.
    // Keeps the page simple: user chooses a section (Régions, Articulations, Segments, Biomécanique, Actions, Utilitaires).
    var allCategories = Array.from(new Set(allSigns.map(function(s){ return s.category||'Autre'; })));
    var preferredOrder = [
      'Régions du corps',
      'Articulations',
      'Segments et structures',
      'Biomécanique',
      'Actions',
      'Symboles utilitaires'
    ];
    var categories = preferredOrder.filter(function(c){ return allCategories.indexOf(c) !== -1; })
      .concat(allCategories.filter(function(c){ return preferredOrder.indexOf(c) === -1; }).sort());

    var selectedCat = categories[0] || '__ALL__';
    if (filterWrap){
      // Include an optional "Tout" tab to display everything.
      var tabs = [{ key: '__ALL__', label: 'TOUT' }].concat(categories.map(function(c){
        // Short labels for the top bar.
        var labelMap = {
          'Régions du corps': 'RÉGIONS',
          'Segments et structures': 'SEGMENTS',
          'Symboles utilitaires': 'UTILITAIRES'
        };
        return { key: c, label: labelMap[c] || c.toUpperCase() };
      }));
      filterWrap.innerHTML = tabs.map(function(t){
        var isActive = (t.key === selectedCat);
        return '<button type="button" class="sign-tab'+(isActive?' active':'')+'" data-cat="'+escapeHTML(t.key)+'">'+escapeHTML(t.label)+'</button>';
      }).join('');
      filterWrap.addEventListener('click', function(e){
        var btn = e.target && e.target.closest && e.target.closest('button[data-cat]');
        if (!btn) return;
        selectedCat = btn.getAttribute('data-cat') || '__ALL__';
        qsa('button.sign-tab', filterWrap).forEach(function(b){
          b.classList.toggle('active', b.getAttribute('data-cat') === selectedCat);
        });
        render();
      });
    }

    function activeCats(){
      if (selectedCat === '__ALL__') return null; // null => no category filtering
      return new Set([selectedCat]);
    }

    function render(){
      var q = (search && search.value || '').trim().toLowerCase();
      var cats = activeCats();
      var filtered = allSigns.filter(function(s){
        if (cats && !cats.has(s.category||'Autre')) return false;
        if (!q) return true;
        return (s.glyph||'').toLowerCase().includes(q) ||
               (s.name||'').toLowerCase().includes(q) ||
               (s.desc||'').toLowerCase().includes(q) ||
               String(s.id||'').includes(q);
      });

      if (count) count.textContent = filtered.length + ' / ' + allSigns.length;

      grid.innerHTML = filtered.map(function(s){
        return (
          '<article class="card sign-card" id="signe-'+escapeHTML(s.id)+'" data-id="'+escapeHTML(s.id)+'">' +
            '<div class="glyph-wrap"><div class="glyph">'+glyphToHTML(s.glyph)+'</div><span class="badge-id">'+escapeHTML(s.id)+'</span></div>' +
            '<h3>'+escapeHTML(s.name)+'</h3>' +
            '<p class="muted">'+escapeHTML(s.desc||'')+'</p>' +
          '</article>'
        );
      }).join('');
    }

    if (search) search.addEventListener('input', render);

    // Detail modal
    var modal = qs('#signModal');
    if (modal){
      var backdrop = qs('#modalBackdrop');
      var closeBtn = qs('#modalClose');
      var mg = qs('#modalGlyph');
      var mid = qs('#modalId');
      var mt = qs('#modalTitle');
      var mc = qs('#modalCat');
      var md = qs('#modalDesc');

      function openSign(s){
        if (mg) mg.innerHTML = glyphToHTML(s.glyph);
        if (mid) mid.textContent = '#' + s.id;
        if (mt) mt.textContent = s.name || '';
        if (mc) mc.textContent = s.category || '';
        if (md) md.textContent = s.desc || '';
        modal.classList.add('open');
        modal.setAttribute('aria-hidden','false');
      }
      function close(){
        modal.classList.remove('open');
        modal.setAttribute('aria-hidden','true');
      }

      grid.addEventListener('click', function(e){
        var card = e.target.closest('.sign-card');
        if (!card) return;
        var id = Number(card.getAttribute('data-id'));
        var s = allSigns.find(function(x){ return x.id === id; });
        if (s) openSign(s);
      });
      if (backdrop) backdrop.addEventListener('click', close);
      if (closeBtn) closeBtn.addEventListener('click', close);
      document.addEventListener('keydown', function(e){
        if (e.key === 'Escape' && modal.classList.contains('open')) close();
      });
    }

    render();
  }

  function boot(){
    fetch('signes.json', {cache:'no-store'})
      .then(function(r){ return r.json(); })
      .then(function(allSigns){
        initQuickModal(allSigns);
        initSignsPage(allSigns);
      })
      .catch(function(){});
  }

  if (document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();

/* =========================================================
   Theme toggle (glass purple/blue)
   ========================================================= */
(function(){
  const root = document.documentElement;
  const key = "kineo-theme";
  const saved = localStorage.getItem(key);
  if(saved){ root.setAttribute("data-theme", saved); }

  const checkbox = document.querySelector('[data-theme-toggle]');
  if(!checkbox) return;

  checkbox.checked = (root.getAttribute("data-theme")==="dark");

  checkbox.addEventListener("change", () => {
    const next = checkbox.checked ? "dark" : "light";
    if(next === "light") root.removeAttribute("data-theme");
    else root.setAttribute("data-theme", "dark");
    localStorage.setItem(key, next);
  });
})();
